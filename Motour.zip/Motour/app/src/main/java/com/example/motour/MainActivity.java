package com.example.motour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private EditText txtusuario;
    private EditText txtcontraseña;

    private Button btnregistrar;
    private Button btnlogin;

    // Variables para registro manual
    private String email="";
    private String contraseña="";

    // Cosas de bases de datos
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
         Se instancia cada uno de los modulos
        */

        // instanciando a firebase
        mAuth = FirebaseAuth.getInstance();

        txtusuario = findViewById(R.id.txtusuario);
        txtcontraseña = findViewById(R.id.txtcontraseña);

        btnregistrar = findViewById(R.id.btnregistrar);
        btnlogin = findViewById(R.id.btningresar);


        // Inicio Evento boton Ingresar
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = txtusuario.getText().toString();
                contraseña = txtcontraseña.getText().toString();

                // Valdiacion de datos
                if (email.isEmpty() && contraseña.isEmpty()){
                    txtusuario.setError("Casilla Vacia");
                    txtcontraseña.setError("Casilla Vacia");
                    return;
                }
                else{
                    if (!email.isEmpty()){
                        if (!validarEmail(email)){
                            txtusuario.setError("Email Invalido. example@motour.com.co");
                            return;
                        }
                    }
                    else{
                        txtusuario.setError("Casilla Vacia");
                        return;
                    }
                    if (!contraseña.isEmpty()){
                        if (contraseña.length()<=6){
                            txtcontraseña.setError("Minimo 7 caracteres");
                            return;
                        }

                    }
                    else{
                        txtcontraseña.setError("Casilla Vacia");
                        return;
                    }
                }


            loginusuario();
            }
        });

        // FIN Evento boton Ingresar

        // Evento de boton registrar
        btnregistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RegistroActivity.class ));
            }
        });
        // FIN Evento de boton registrar


    }


    // metodo login
    private void loginusuario(){
        mAuth.signInWithEmailAndPassword(email, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Inicio sesion", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Perfil.class));
                    finish();
                }
                else{
                    Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos. Compruebe sus datos", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    protected void onStart(){
        super.onStart();

        // validar si ya inicio sesion
        if(mAuth.getCurrentUser() != null){
            startActivity(new Intent(MainActivity.this, Perfil.class));
            finish();
        }
    }

    public boolean validarEmail(String email) {
        Pattern pattern = Patterns.EMAIL_ADDRESS;
        return pattern.matcher(email).matches();
    }

}
