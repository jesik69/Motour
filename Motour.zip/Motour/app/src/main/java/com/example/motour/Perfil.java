package com.example.motour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Perfil extends AppCompatActivity {

    private TextView txtnombrerec;
    private TextView txtusuariorec;

    private Button btncerrar;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        txtnombrerec = findViewById(R.id.txtnombrerec);
        txtusuariorec =  findViewById(R.id.txtusuariorec);

        btncerrar = findViewById(R.id.btncerrar);

        // Inicio Evento boton Cerrar Sesion
        btncerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                startActivity(new Intent(Perfil.this, MainActivity.class));
                finish();
            }
        });
        // FIN Evento boton Cerrar Sesion
        obtenerinformacion();
    }

    // metodo para obtener informacion del usuario
    private void obtenerinformacion(){
        String id = mAuth.getCurrentUser().getUid(); // Me trae el id cuando se crea el usuario
        mDatabase.child("Usuarios").child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    String nombre = dataSnapshot.child("nombre").getValue().toString();
                    String usuario = dataSnapshot.child("email").getValue().toString();

                    txtnombrerec.setText(nombre);
                    txtusuariorec.setText(usuario);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
